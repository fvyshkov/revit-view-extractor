using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using RevitViewExporter.Forms;
using View = Autodesk.Revit.DB.View;
using Form = System.Windows.Forms.Form;

namespace RevitViewExporter.Commands
{
    [Transaction(TransactionMode.Manual)]
    public class ExportViewsCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            try
            {
                // Get the Revit application and document
                UIApplication uiapp = commandData.Application;
                UIDocument uidoc = uiapp.ActiveUIDocument;
                Document doc = uidoc.Document;

                // Get all views from the document
                List<View> views = GetExportableViews(doc);

                if (views.Count == 0)
                {
                    TaskDialog.Show("Warning", "No exportable views found in the document.");
                    return Result.Succeeded;
                }

                // Show the view selector dialog
                using (ViewSelectorForm form = new ViewSelectorForm(views))
                {
                    if (form.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        // Get selected views
                        List<View> selectedViews = form.SelectedViews;
                        
                        if (selectedViews.Count == 0)
                        {
                            TaskDialog.Show("Warning", "No views selected for export.");
                            return Result.Succeeded;
                        }

                        // Ask for export folder
                        System.Windows.Forms.FolderBrowserDialog folderDialog = new System.Windows.Forms.FolderBrowserDialog();
                        folderDialog.Description = "Select folder for exported images";
                        
                        if (folderDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                        {
                            string exportFolder = folderDialog.SelectedPath;
                            
                            // Export selected views
                            int exportedCount = ExportViewsToImages(doc, selectedViews, exportFolder);
                            
                            // Show success message
                            TaskDialog.Show("Success", $"Successfully exported {exportedCount} view(s) to:\n{exportFolder}");
                        }
                    }
                }

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return Result.Failed;
            }
        }

        private List<View> GetExportableViews(Document doc)
        {
            // Get all views that can be exported
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            collector.OfClass(typeof(View));
            
            List<View> exportableViews = new List<View>();
            
            foreach (View view in collector)
            {
                // Skip view templates, system views, and non-exportable views
                if (view.IsTemplate || view.ViewType == ViewType.SystemBrowser || 
                    view.ViewType == ViewType.ProjectBrowser || view.ViewType == ViewType.Internal ||
                    view.ViewType == ViewType.Undefined || !view.CanBePrinted)
                {
                    continue;
                }
                
                // Skip views with <3D> in the name (typically section boxes)
                if (view.Name.Contains("<3D>"))
                {
                    continue;
                }
                
                exportableViews.Add(view);
            }
            
            // Sort views by name
            return exportableViews.OrderBy(v => v.Name).ToList();
        }

        private int ExportViewsToImages(Document doc, List<View> views, string exportFolder)
        {
            int exportedCount = 0;
            
            // Create export options
            ImageExportOptions options = new ImageExportOptions();
            options.ZoomType = ZoomFitType.FitToPage;
            options.PixelSize = 2000; // Image width in pixels
            options.ImageResolution = ImageResolution.DPI_300;
            options.ExportRange = ExportRange.SetOfViews;
            options.HLRandWFViewsFileType = ImageFileType.PNG;
            options.ShadowViewsFileType = ImageFileType.PNG;
            
            // Create transaction for exporting
            using (Transaction t = new Transaction(doc, "Export Views to Images"))
            {
                t.Start();
                
                // Создаем простую форму прогресса
                System.Windows.Forms.Form progressForm = new System.Windows.Forms.Form();
                progressForm.Text = "Exporting Views...";
                progressForm.Size = new System.Drawing.Size(400, 100);
                progressForm.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
                progressForm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
                progressForm.MaximizeBox = false;
                progressForm.MinimizeBox = false;

                System.Windows.Forms.ProgressBar progressBar = new System.Windows.Forms.ProgressBar();
                progressBar.Minimum = 0;
                progressBar.Maximum = views.Count;
                progressBar.Value = 0;
                progressBar.Width = 360;
                progressBar.Location = new System.Drawing.Point(20, 20);

                System.Windows.Forms.Label progressLabel = new System.Windows.Forms.Label();
                progressLabel.Text = "Preparing...";
                progressLabel.Location = new System.Drawing.Point(20, 50);
                progressLabel.Width = 360;

                progressForm.Controls.Add(progressBar);
                progressForm.Controls.Add(progressLabel);
                progressForm.Show();
                
                // Export each view
                foreach (View view in views)
                {
                    try
                    {
                        // Update progress
                        progressBar.Value = exportedCount + 1;
                        progressLabel.Text = $"Exporting {exportedCount + 1} of {views.Count}: {view.Name}";
                        System.Windows.Forms.Application.DoEvents();
                        
                        // Set the view to export
                        ICollection<ElementId> viewSet = new List<ElementId> { view.Id };
                        options.SetViewsAndSheets(viewSet);
                        
                        // Set the file name (sanitize view name)
                        string fileName = SanitizeFileName(view.Name);
                        string filePath = Path.Combine(exportFolder, fileName);
                        
                        // Export the view
                        options.FilePath = filePath;
                        doc.ExportImage(options);
                        
                        exportedCount++;
                    }
                    catch (Exception ex)
                    {
                        TaskDialog.Show("Export Error", $"Error exporting view '{view.Name}': {ex.Message}");
                    }
                }
                
                // Close progress dialog
                progressForm.Close();
                
                t.Commit();
            }
            
            return exportedCount;
        }

        private string SanitizeFileName(string fileName)
        {
            // Replace invalid file name characters
            foreach (char c in Path.GetInvalidFileNameChars())
            {
                fileName = fileName.Replace(c, '_');
            }
            
            // Add .png extension if not present
            if (!fileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase))
            {
                fileName += ".png";
            }
            
            return fileName;
        }
    }
}
